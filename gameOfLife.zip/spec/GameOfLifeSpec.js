describe('Testing the functionality, create grid', ()=>{
	let grid = new ToDo();
   	const done = grid.initializeGrid(3,4);
	it('should have 3 rows', ()=>{
		expect(grid.getGrid().length).toBe(3);
	})

	it('should have 4 columns', ()=>{
    	expect(grid.getGrid()[0].length).toBe(4);
  	})
})