function ToDo(){
  this.grid = [];
}

ToDo.prototype.initializeGrid= function(rows, columns){
//function initializeGrid(rows, columns){
	var r;
	for (r=0; r<rows; r++) {
	 var curColumn = [];
	 	var c;
	 	for(c=0; c<columns; c++) {
	 		curColumn.push(0);
	 	}
	 	this.grid.push(curColumn);
	}
}

ToDo.prototype.getGrid= function(){
  return this.grid;
}

ToDo.prototype.renderGrid= function(){

	console.log(this.grid.length);
	var gameTableHTML = document.getElementById("gameTable");
	gameTableHTML.innerHTML = "";
	for (r=0; r<this.grid.length; r++) {
		var rowElement = document.createElement("tr");
		console.log(rowElement);
		gameTableHTML.appendChild(rowElement);
	 	var c;
	 	for(c=0; c<this.grid[r].length; c++) {
	 		var cellState = this.grid[r][c];
	 		var columnElement = document.createElement("td");
	 		columnElement.innerHTML = cellState;
	 		var cellAtt = document.createAttribute("id");
	 		var cellId = "cell" + r + "-" + c;
	 		cellAtt.value = cellId;
	 		columnElement.setAttributeNode(cellAtt);
	 		rowElement.appendChild(columnElement);

			document.getElementById(cellId).addEventListener("click", function(e){
				//e.target
				console.log("you clicked a cell!");
				
				//todo: update grid!
			}, false);
	 	}

	}
}

function registerEvents(){
	document.gameSize.startGame.addEventListener("click",getSizeInputs,false);
}

function getSizeInputs(){
	var inputRows = document.gameSize.nRows.value;
	var inputColumns = document.gameSize.nColumns.value;
	let grid = new ToDo();
	grid.initializeGrid(inputRows,inputColumns);
//	console.log(grid);
	grid.renderGrid();
}